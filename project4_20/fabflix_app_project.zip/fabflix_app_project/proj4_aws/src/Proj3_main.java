
public class Proj3_main {
	
	public static void main(String[] args){
		ActorParser actor = new ActorParser();
		actor.runExample();
		
		movieParser movie = new movieParser();
		movie.runExample();
		
		castParser cast = new castParser();
		cast.runExample();
	}
	
	
	
	
	
}
