package HelperClasses;

public class keys {
    public static final String SITE_KEY ="6LfiJhYUAAAAAG_urVHOpCdo4o8KUXPohp9LM75c";

    public static final String SECRET_KEY ="6LfiJhYUAAAAAFxkQGOpIoqNs_26KXO0U9l4S-C_";

}

